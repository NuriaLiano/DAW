class SuperH{
    constructor (grupo, ciudad, anio, base, activo){
        this.grupo = grupo;
        this.ciudad = ciudad;
        this.anio = anio;
        this.base = base;
        this.activo = activo;
        
    }
}