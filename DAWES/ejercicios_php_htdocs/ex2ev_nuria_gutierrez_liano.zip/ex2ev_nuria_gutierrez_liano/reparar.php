<?php
    interface iReparar{
        
        public function repararmotor(){
            echo "reparar motor";
        }
        public function repararruedas(){
            echo "reparar ruedas";
        }
    }
?>