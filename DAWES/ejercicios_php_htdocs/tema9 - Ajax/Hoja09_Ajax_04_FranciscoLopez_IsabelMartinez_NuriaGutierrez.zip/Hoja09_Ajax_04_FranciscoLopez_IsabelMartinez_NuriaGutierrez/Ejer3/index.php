<?php 

include_once 'includes/framework.php';

include_once 'componentes/commons/header.php';
echo loader($componente);
include_once 'componentes/commons/footer.php';
?>