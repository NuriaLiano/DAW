
    <link rel="stylesheet" href="css/estilos_pagar.css">
    <title>Pasarela de pago</title>
</head>
<body>
    <div class="titulo">
        <h1>Gracias por tu compra</h1>
        <p>El producto llegara lo antes posible</p>
    </div>
    <div class="texto-final">
        <img src="img/smile.png" >
        <form action="" method="POST">
        	<input type="submit" name="volver" value="Volver a productos" class="btn">
        </form>
        
        <h2>Esperamos verte pronto</h2>
        
    </div>
</body>
</html>