
<!-- Estilos -->
<link rel="stylesheet" href="css/estilos_index.css">
</head>

<body>
	<!-- Acceso -->
	<div class="login">
		<div class="login-caja">
			<form name="reservar" action="" method="POST">
				<div class="login-titulo">
					<h2>Login de usuarios</h2>
				</div>
				<div class="login-form">
					<div class="login-inputs">
						<input type="text" class="login-field" id="buscador"
							name="usuario" placeholder="Introduce tu usuario" require> <label
							class="login-field-icon fui-user" for="login-name"></label>
					</div>
					<div class="login-inputs">
						<input type="password" class="login-field" id="buscador"
							name="password" placeholder="Introduce tu password" require> <label
							class="login-field-icon fui-lock" for="login-pass"></label>
					</div>
					<input type="submit" name="login" value="Login" class="btn"> 
					<input type="submit" name="registro" value="Registro" class="btn-rg"></input>
				</div>
				<!-- Pie -->
				<footer class="pie"> &copy; I.E.S. Miguel Herrero </footer>
				<!-- Fin pie -->
			</form>
		</div>
	</div>
	<!-- Fin botonera -->




	</div>
	<!-- Fin acceso -->