 <title>Registro de usuarios</title>

    <!-- Estilos -->
    <link rel="stylesheet" href="css/estilos_registro.css">


</head>

<body>
    
            
            <div class="login">
            <div class="login-caja">
                <form name="registro" action="" method="POST">
                <div class="login-titulo">
                    <h2>Registro de usuarios</h2>
                </div>
            <div class="login-form">
                    <div class="login-inputs">
                        <input type="text" class="login-field" id="usuario" name="usuario" placeholder="introduce usuario" required>
                        <label class="login-field-icon fui-user" for="login-name"></label>    
                    </div>
                    <div class="login-inputs">
                        <input type="password" class="login-field" id="password" name="password" placeholder="introduce password" required>
                        <label class="login-field-icon fui-lock" for="login-pass"></label>
                    </div>
                    <div class="login-inputs">
                        <input type="password" class="login-field" id="confirmar_password" name="confirmar_password" placeholder="confirma tu password" required>
                        <label class="login-field-icon fui-lock" for="login-pass"></label>
                    </div>
                    <input type="submit" name="regis" value="Registro" class="btn-rg">
                    
                </div>
                       <!-- Pie -->
        <footer class="pie">
            &copy; I.E.S. Miguel Herrero
        </footer>
                </section>
                <!-- Fin botonera -->

                <!-- Control de usuarios -->
                <section>
   
                </section>
                <!-- Fin control -->
            </form>
            <!-- Fin formulario -->
        </main>
        <!-- Fin cuerpo -->

    </div>
    <!-- Fin acceso -->