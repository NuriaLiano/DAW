<?php 
    global $funcion2;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Inserte los datos del teléfono</h2>
    <br>
    Modelo <input type="text">
    Marca <input type="text">
    Memoria <input type="number">
    Precio <input type="number">
    Fecha de adquisicion <input type="date" name="fecha" id="fecha">
    <br>
    <input type="button" value="Guardar datos del telefono" >

</body>
</html>