function fallo(accion) {
    alert(`${accion} fallido`);
}

function cesta_vacia() {
    alert(`La cesta está vacía`);
}