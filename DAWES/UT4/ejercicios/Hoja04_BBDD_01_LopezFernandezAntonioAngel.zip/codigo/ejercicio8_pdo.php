<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoja04_BBDD_01 - Ejercicio 8 por Antonio López (DAW220)</title>

    <!-- Estilos -->
    <style>
        * {
            font-family: Arial, Helvetica, sans-serif;
        }

        input[type=submit] {
            margin-top: 2em;
            padding: 0.5em;

            color: white;
            background-color: green;
            font-weight: bold;
        }

        input[type=number] {
            max-width: 5em;
        }

        table,
        tr,
        th,
        td {
            border: 2px solid black;
            border-collapse: collapse;
            padding: 1em;
            min-width: 15em;

            color: white;
            background-color: green;
            text-align: center;
        }

        td {
            color: black;
            background-color: lightgreen;
        }
    </style>
</head>

<body>
    <!-- Cabecera -->
    <header>
        <h1>Hoja04_BBDD_01 - Ejercicio 8 por Antonio López (DAW220)</h1>
        <hr>
    </header>
    <!-- Fin cabecera -->

    <!-- Principal -->
    <main>
        <h2>Jugadores de la NBA</h2>
        <hr>

        <?php
        require_once "funcionesBasket.php";

        // Obtenemos la lista de equipos
        $lista_equipos = getEquipos();
        ?>

        <!-- Formulario -->
        <form action="ejercicio8_pdo.php" method="post">
            <!-- Selección de equipo -->
            <section>
                <label for="equipo">Equipo: </label>
                <select name="equipo" id="equipo">
                    <?php
                    /// INSERCIÓN EQUIPO EN CADA OPTION DE LA SELECT
                    foreach ($lista_equipos as $equipo) {
                        $nombre_equipo = $equipo['nombre'];

                        if (isset($_POST["equipo"]) && $nombre_equipo == $_POST["equipo"]) {
                    ?>
                            <option value="<?= $nombre_equipo ?>" selected><?= $nombre_equipo ?></option>
                        <?php
                        } else {
                        ?>
                            <option value="<?= $nombre_equipo ?>"><?= $nombre_equipo ?></option>
                    <?php
                        }
                    }
                    // FIN INSERCIÓN
                    ?>
                </select>
            </section>
            <!-- Fin selección de equipo -->

            <!-- Botonera -->
            <section>
                <input type="submit" name="mostrar" value="Mostrar" />
                <hr>
            </section>
            <!-- Fin botonera -->
        </form>
        <!-- Fin formulario -->

        <?php
        if (isset($_POST['mostrar'])) {
            // Obtenemos una lista con los jugadores del equipo seleccionado
            $equipo_seleccionado = $_POST["equipo"];
            $jugadores = getJugadores($equipo_seleccionado);
        ?>
            <!-- Nombre y peso de los jugadores -->
            <section>
                <!-- Formulario pesos -->
                <form action="ejercicio8.php" method="post">
                    <!-- Tabla -->
                    <table>
                        <tr>
                            <th>NOMBRE</th>
                            <th>PESO</th>
                        </tr>

                        <!-- Equipo como input oculto -->
                        <input type="hidden" name="equipo" value="<?= $equipo_seleccionado ?>" />

                        <?php
                        // Cada jugador es una fila de la tabla con su peso
                        foreach ($jugadores as $jugador) {
                        ?>
                            <tr>
                                <td>
                                    <?= $jugador['nombre'] ?>
                                    <input type="hidden" name="codigos[]" value="<?= $jugador['codigo'] ?>">
                                </td>
                                <td>
                                    <input type="number" step="0.01" name="pesos[]" value="<?= $jugador['peso'] ?>"> kg.
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </table>
                    <!-- Fin tabla -->

                    <!-- Botonera -->
                    <section>
                        <input type="submit" name="actualizar" value="Actualizar" />
                        <hr>
                    </section>
                    <!-- Fin botonera -->
                </form>
                <!-- Fin formulario pesos -->
            </section>
            <!-- Fin nombre y peso de los jugadores -->
        <?php
        } elseif (isset($_POST["actualizar"])) {
            // ACTUALIZACIÓN DE LOS PESOS DE LOS JUGADORES
            $codigos = $_POST["codigos"];
            $pesos = $_POST["pesos"];

            foreach (array_combine($codigos, $pesos) as $codigo => $peso) {
                actualizaPeso(floatval($peso), intval($codigo));
            }
            // FIN ACTUALIZACIÓN
        }
        ?>
        <!-- Fin tabla -->
    </main>
    <!-- Fin principal -->

    <!-- Pie -->
    <footer>
        <hr>
        <p>Desarrollado por Antonio López (DAW220)</p>
    </footer>
    <!-- Fin pie -->
</body>

</html>