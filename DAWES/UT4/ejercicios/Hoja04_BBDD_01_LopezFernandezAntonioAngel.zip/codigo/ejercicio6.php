<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoja04_BBDD_01 - Ejercicio 6 por Antonio López (DAW220)</title>

    <!-- Estilos -->
    <style>
        * {
            font-family: Arial, Helvetica, sans-serif;
        }

        input[type=submit] {
            margin-top: 2em;
            padding: 0.5em;

            color: white;
            background-color: green;
            font-weight: bold;
        }

        table,
        tr,
        th,
        td {
            border: 2px solid black;
            border-collapse: collapse;
            padding: 1em;
            min-width: 15em;

            color: white;
            background-color: green;
            text-align: center;
        }

        td {
            color: black;
            background-color: lightgreen;
        }
    </style>
</head>

<body>
    <!-- Cabecera -->
    <header>
        <h1>Hoja04_BBDD_01 - Ejercicio 6 por Antonio López (DAW220)</h1>
        <hr>
    </header>
    <!-- Fin cabecera -->

    <!-- Principal -->
    <main>
        <h2>Jugadores de la NBA</h2>
        <hr>

        <?php
        require_once "funcionesBasket.php";

        // Obtenemos la lista de equipos
        $lista_equipos = getEquipos();
        ?>

        <!-- Formulario -->
        <form action="ejercicio6.php" method="post">
            <!-- Selección de equipo -->
            <section>
                <label for="equipo">Equipo: </label>
                <select name="equipo" id="equipo">
                    <?php
                    // INSERCIÓN EQUIPO EN CADA OPTION DE LA SELECT
                    foreach ($lista_equipos as $equipo) {
                        $nombre_equipo = $equipo['nombre'];

                        if (isset($_POST["equipo"]) && $nombre_equipo == $_POST["equipo"]) {
                    ?>
                            <option value="<?= $nombre_equipo ?>" selected><?= $nombre_equipo ?></option>
                        <?php
                        } else {
                        ?>
                            <option value="<?= $nombre_equipo ?>"><?= $nombre_equipo ?></option>
                    <?php
                        }
                    }
                    // FIN INSERCIÓN
                    ?>
                </select>
            </section>
            <!-- Fin selección de equipo -->

            <!-- Botonera -->
            <section>
                <input type="submit" name="mostrar" value="Mostrar" />
                <hr>
            </section>
            <!-- Fin botonera -->
        </form>
        <!-- Fin formulario -->

        <!-- Tabla -->
        <?php
        if (isset($_POST["mostrar"])) {
            // Obtenemos una lista con los jugadores del equipo seleccionado
            $equipo_seleccionado = $_POST["equipo"];
            $jugadores = getJugadores($equipo_seleccionado);
        ?>
            <section>
                <table>
                    <tr>
                        <th>NOMBRE</th>
                        <th>PESO</th>
                    </tr>

                    <?php
                    // Cada jugador es una fila de la tabla
                    foreach ($jugadores as $jugador) {
                    ?>

                    <tr>
                        <td><?= $jugador['nombre'] ?></td>
                        <td><?= $jugador['peso'] ?> kg.</td>
                    </tr>

                    <?php
                    }
                    ?>
                </table>
            </section>
        <?php
        }
        ?>
        <!-- Fin tabla -->
    </main>
    <!-- Fin principal -->

    <!-- Pie -->
    <footer>
        <hr>
        <p>Desarrollado por Antonio López (DAW220)</p>
    </footer>
    <!-- Fin pie -->
</body>

</html>