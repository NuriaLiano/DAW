<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoja04_BBDD_01 - Ejercicio 7 por Antonio López (DAW220)</title>

    <!-- Estilos -->
    <style>
        * {
            font-family: Arial, Helvetica, sans-serif;
        }

        input[type=submit] {
            margin-top: 2em;
            padding: 0.5em;

            color: white;
            background-color: green;
            font-weight: bold;
        }

        section {
            max-width: 5em;
        }

        .gris_claro {
            border-color: #e6e6e6;
        }
    </style>
</head>

<body>
    <!-- Cabecera -->
    <header>
        <h1>Hoja04_BBDD_01 - Ejercicio 7 por Antonio López (DAW220)</h1>
        <hr>
    </header>
    <!-- Fin cabecera -->

    <!-- Principal -->
    <main>
        <h2>Traspasos de jugadores</h2>
        <hr>

        <?php
        require_once "funcionesBasket.php";

        // Obtenemos la lista de equipos
        $lista_equipos = getEquipos();
        ?>

        <!-- Formulario -->
        <form action="ejercicio7_pdo.php" method="post">
            <!-- Selección de equipo -->
            <section>
                <label for="equipo">Equipo: </label>
                <select name="equipo" id="equipo">
                    <?php
                    // INSERCIÓN EQUIPO EN CADA OPTION DE LA SELECT
                    foreach ($lista_equipos as $equipo) {
                        $nombre_equipo = $equipo['nombre'];

                        if (isset($_POST["equipo"]) && $nombre_equipo == $_POST["equipo"]) {
                    ?>
                            <option value="<?= $nombre_equipo ?>" selected><?= $nombre_equipo ?></option>
                        <?php
                        } else {
                        ?>
                            <option value="<?= $nombre_equipo ?>"><?= $nombre_equipo ?></option>
                    <?php
                        }
                    }
                    // FIN INSERCIÓN
                    ?>
                </select>
            </section>
            <!-- Fin selección de equipo -->

            <!-- Botonera -->
            <section>
                <input type="submit" name="mostrar" value="Mostrar" />
                <hr>
            </section>
            <!-- Fin botonera -->
        </form>
        <!-- Fin formulario -->

        <?php
        if (isset($_POST["mostrar"])) {
        ?>
            <h3>Baja y alta de jugadores:</h3>
            <hr class="gris_claro">

            <!-- Inicio formulario de baja de jugador/alta de jugador -->
            <form action="ejercicio7_pdo.php" method="post">
                <?php
                // Obtenemos una lista con los jugadores del equipo seleccionado
                $equipo_seleccionado = $_POST["equipo"];
                $jugadores = getJugadores($equipo_seleccionado);
                ?>

                <!-- Baja de jugador -->
                <label for="codigo_jugador_antiguo">Baja del jugador: </label>
                <select name="codigo_jugador_antiguo" id="codigo_jugador_antiguo">
                    <?php
                    foreach ($jugadores as $jugador) {
                    ?>
                        <option value="<?= $jugador['codigo'] ?>"><?= $jugador['nombre'] ?></option>
                    <?php
                    }
                    ?>
                </select>
                <hr class="gris_claro">
                <!-- Fin baja de jugador -->

                <!-- Alta nuevo jugador -->
                <h4>Datos del nuevo jugador</h4>
                <hr class="gris_claro">

                <!-- Equipo -->
                <input type="hidden" name="equipo" value="<?= $equipo_seleccionado ?>">
                <!-- Fin equipo -->

                <!-- Nombre -->
                <section>
                    <label for="nombre_nuevo">Nombre: </label>
                    <input type="text" name="nombre_nuevo" id="nombre_nuevo" />
                </section>
                <hr class="gris_claro">
                <!-- Fin nombre -->

                <!-- Procedencia -->
                <section>
                    <label for="procedencia">Procedencia: </label>
                    <input type="text" name="procedencia" id="procedencia" />
                </section>
                <hr class="gris_claro">
                <!-- Fin procedencia -->

                <!-- Altura -->
                <section>
                    <label for="altura">Altura: </label>
                    <input type="number" name="altura" id="altura" step="0.01" required />
                </section>
                <hr class="gris_claro">
                <!-- Fin altura -->

                <!-- Peso -->
                <section>
                    <label for="peso">Peso: </label>
                    <input type="number" name="peso" id="peso" step="0.01" required />
                </section>
                <hr class="gris_claro">
                <!-- Fin peso -->

                <!-- Posición -->
                <section>
                    <label for="posicion">Posición: </label>
                    <select name="posicion" id="posicion">
                        <option value="C">C</option>
                        <option value="C-F">C-F</option>
                        <option value="F">F</option>
                        <option value="F-C">F-C</option>
                        <option value="F-G">F-G</option>
                        <option value="G">G</option>
                        <option value="G-F">G-F</option>
                    </select>
                </section>
                <!-- Fin posición -->

                <!-- Botón -->
                <section>
                    <input type="submit" name="traspasar" value="Realizar traspaso">
                </section>
                <!-- Fin botón -->

                <!-- Fin alta nuevo jugador -->
            </form>
        <?php
        }

        // INICIO TRASPASO JUGADOR
        if (isset($_POST["traspasar"])) {
            $codigo_jugador_antiguo = $_POST["codigo_jugador_antiguo"];
            $nombre = $_POST["nombre_nuevo"];
            $procedencia = $_POST["procedencia"];
            $altura = $_POST["altura"];
            $peso = $_POST["peso"];
            $posicion = $_POST["posicion"];
            $equipo = $_POST["equipo"];

            actualizaJugadorPDO($codigo_jugador_antiguo, $nombre, $procedencia, $altura, $peso, $posicion, $equipo);
        }
        // FIN TRASPASO JUGADOR
        ?>
        <!-- Fin formulario de baja de jugador/alta de jugador -->
    </main>
    <!-- Fin principal -->

    <!-- Pie -->
    <footer>
        <hr>
        <p>Desarrollado por Antonio López (DAW220)</p>
    </footer>
    <!-- Fin pie -->
</body>

</html>