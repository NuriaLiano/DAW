<?php
require_once 'getConexion.php';

/**
 * Función que devuelve un array con los equipos de la NBA (con MySQLi)
 * 
 * @return array Array con los equipos de la NBA
 */
function getEquipos()
{
    $conexion = getConexionMySQLi('dwes_01_nba');
    $consulta = $conexion->stmt_init();

    // BINDING CONSULTA
    $consulta->prepare('SELECT nombre, ciudad, conferencia, division FROM equipos');
    $consulta->execute();
    $consulta->bind_result($nombre, $ciudad, $conferencia, $division);

    // VOLCAMOS EL RESULTADO EN UN ARRAY
    $equipos = [];
    while ($consulta->fetch()) {
        $equipos[] = [
            'nombre' => $nombre,
            'ciudad' => $ciudad,
            'conferencia' => $conferencia,
            'division' => $division
        ];
    }

    // CERRAMOS CONEXIÓN
    $consulta->close();

    return $equipos;
}

/**
 * Función que devuelve un array con los equipos de la NBA (con PDO)
 * 
 * @return array Array con los equipos de la NBA
 */
function getEquiposPDO()
{
    $conexion = getConexionPDO('dwes_01_nba');

    // BINDING CONSULTA
    $consulta = $conexion->prepare('SELECT nombre, ciudad, conferencia, division FROM equipos');
    $consulta->execute();

    // VOLCAMOS EL RESULTADO EN UN ARRAY
    $equipos = [];
    while ($equipo = $consulta->fetch()) {
        $equipos[] = [
            'nombre' => $equipo['nombre'],
            'ciudad' => $equipo['ciudad'],
            'conferencia' => $equipo['conferencia'],
            'division' => $equipo['division']
        ];
    }

    // CERRAMOS CONEXIÓN
    unset($conexion);

    return $equipos;
}

/**
 * Función que devuelve un array con los jugadores de un equipo de la NBA (con MySQLi)
 * 
 * @param string $nombre_equipo Nombre del equipo de la NBA
 * 
 * @return array Array con los jugadores de la NBA
 */
function getJugadores($nombre_equipo)
{
    $conexion = getConexionMySQLi('dwes_01_nba');
    $consulta = $conexion->stmt_init();

    // BINDING CONSULTA
    $consulta->prepare('SELECT jugadores.codigo, jugadores.nombre, jugadores.procedencia, jugadores.altura, jugadores.peso, jugadores.posicion FROM jugadores LEFT JOIN equipos ON jugadores.nombre_equipo = equipos.nombre WHERE nombre_equipo = ?');
    $consulta->bind_param('s', $nombre_equipo);
    $consulta->execute();
    $consulta->bind_result($codigo, $nombre, $procedencia, $altura, $peso, $posicion);

    // VOLCAMOS EL RESULTADO EN UN ARRAY
    $jugadores = [];
    while ($consulta->fetch()) {
        $jugadores[] = [
            'codigo' => $codigo,
            'nombre' => $nombre,
            'procedencia' => $procedencia,
            'altura' => $altura,
            'peso' => $peso,
            'posicion' => $posicion
        ];
    }

    // CERRAMOS CONEXIÓN
    $consulta->close();

    return $jugadores;
}

/**
 * Función que devuelve un array con los jugadores de un equipo de la NBA (con PDO)
 * 
 * @param string $nombre_equipo Nombre del equipo de la NBA
 * 
 * @return array Array con los jugadores de la NBA
 */
function getJugadoresPDO($nombre_equipo)
{
    $conexion = getConexionPDO('dwes_01_nba');

    // BINDING CONSULTA
    $consulta = $conexion->prepare('SELECT jugadores.codigo, jugadores.nombre, jugadores.procedencia, jugadores.altura, jugadores.peso, jugadores.posicion FROM jugadores LEFT JOIN equipos ON jugadores.nombre_equipo = equipos.nombre WHERE nombre_equipo = ?');
    $consulta->bindParam(1, $nombre_equipo);
    $consulta->execute();

    // VOLCAMOS EL RESULTADO EN UN ARRAY
    $jugadores = [];
    while ($jugador = $consulta->fetch()) {
        $jugadores[] = [
            'codigo' => $jugador['codigo'],
            'nombre' => $jugador['nombre'],
            'procedencia' => $jugador['procedencia'],
            'altura' => $jugador['altura'],
            'peso' => $jugador['peso'],
            'posicion' => $jugador['posicion']
        ];
    }

    // CERRAMOS CONEXIÓN
    unset($conexion);

    return $jugadores;
}

/**
 * Función que actualiza el peso de un jugador de la NBA (con MySQLi)
 * 
 * @param float $peso Nuevo peso del jugador de la NBA
 * @param integer $id_jugador Codigo del jugador de la NBA
 * 
 * @return void
 */
function actualizaPeso($peso, $id_jugador)
{
    $conexion = getConexionMySQLi('dwes_01_nba');

    // BINDING Y EJECUCIÓN ACTUALIZACIÓN
    $consulta = $conexion->prepare('UPDATE jugadores SET jugadores.peso = ? WHERE codigo = ?');
    $consulta->bind_param('di', $peso, $id_jugador);
    $consulta->execute();

    // CERRAMOS CONEXIÓN
    $conexion->close();
}

/**
 * Función que actualiza el peso de un jugador de la NBA (con PDO)
 * 
 * @param float $peso Nuevo peso del jugador de la NBA
 * @param integer $id_jugador Codigo del jugador de la NBA
 * 
 * @return void
 */
function actualizaPesoPDO($peso, $id_jugador)
{
    $conexion = getConexionPDO('dwes_01_nba');

    // BINDING Y EJECUCIÓN ACTUALIZACIÓN
    $consulta = $conexion->prepare('UPDATE jugadores SET jugadores.peso = ? WHERE codigo = ?');
    $consulta->bindParam('di', $peso, $id_jugador);
    $consulta->execute();

    // CERRAMOS CONEXIÓN
    unset($conexion);
}

/**
 * Función que sustituye un jugador por otro de la NBA
 * 
 * @param int $codigo_jugador_antiguo Código del jugador antiguo de la NBA
 * @param string $nombre Nombre del nuevo jugador de la NBA
 * @param string $procedencia Procedencia del nuevo jugador de la NBA
 * @param double $altura Altura del nuevo jugador de la NBA
 * @param double $peso Peso del nuevo jugador de la NBA
 * @param string $posicion Posición del nuevo jugador de la NBA
 * @param string $nombre_equipo Equipo del nuevo jugador de la NBA
 * 
 * @return boolean Resultado de la transacción
 */
function actualizaJugador($codigo_jugador_antiguo, $nombre, $procedencia, $altura, $peso, $posicion, $nombre_equipo)
{
    // Controlamos con $correcto que la transacción se haga bien
    $correcto = false;
    $conexion = getConexionMySQLi('dwes_01_nba');

    // Desactivamos autocommit
    mysqli_autocommit($conexion, false);

    // Borrado de estadisticas
    $borrado_estadisticas = $conexion->prepare('DELETE FROM estadisticas WHERE jugador = ?');
    $borrado_estadisticas->bind_param('s', $codigo_jugador_antiguo);
    $borrado_estadisticas->execute();

    // Borrado de jugador
    $borrado_jugador = $conexion->prepare('DELETE FROM jugadores WHERE codigo = ?');
    $borrado_jugador->bind_param('s', $codigo_jugador_antiguo);
    $borrado_jugador->execute();
    $numero_jugadores_borrados = $borrado_jugador->affected_rows;

    // Inserción de jugador
    $insercion_jugador = $conexion->prepare('INSERT INTO jugadores (codigo, nombre, procedencia, altura, peso, posicion, nombre_equipo) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $insercion_jugador->bind_param('issddss', $codigo_jugador_antiguo, $nombre, $procedencia, $altura, $peso, $posicion, $nombre_equipo);
    $insercion_jugador->execute();
    $numero_jugadores_insertados = $insercion_jugador->affected_rows;

    // Si el número de jugadores borrados e insertados es igual a 1, hacemos la transacción
    if (($numero_jugadores_borrados == $numero_jugadores_insertados) && ($numero_jugadores_borrados == 1)) {
        $conexion->commit();
        $correcto = true;
    } else {
        $conexion->rollback();
    }

    // En cualquier caso cerramos la conexión y devolvemos el resultado
    mysqli_close($conexion);
    return $correcto;
}

/**
 * Función que sustituye un jugador por otro de la NBA (con PDO)
 * 
 * @param int $codigo_jugador_antiguo Código del jugador antiguo de la NBA
 * @param string $nombre Nombre del nuevo jugador de la NBA
 * @param string $procedencia Procedencia del nuevo jugador de la NBA
 * @param double $altura Altura del nuevo jugador de la NBA
 * @param double $peso Peso del nuevo jugador de la NBA
 * @param string $posicion Posición del nuevo jugador de la NBA
 * @param string $nombre_equipo Equipo del nuevo jugador de la NBA
 * 
 * @return boolean Resultado de la transacción
 */
function actualizaJugadorPDO($codigo_jugador_antiguo, $nombre, $procedencia, $altura, $peso, $posicion, $nombre_equipo)
{
    // Controlamos con $correcto que la transacción se haga bien
    $correcto = false;
    $conexion = getConexionPDO('dwes_01_nba');

    // Desactivamos autocommit
    mysqli_autocommit($conexion, false);

    // Borrado de estadisticas
    $borrado_estadisticas = $conexion->prepare('DELETE FROM estadisticas WHERE jugador = ?');
    $borrado_estadisticas->bindParam('s', $codigo_jugador_antiguo);
    $borrado_estadisticas->execute();

    // Borrado de jugador
    $borrado_jugador = $conexion->prepare('DELETE FROM jugadores WHERE codigo = ?');
    $borrado_jugador->bindParam('s', $codigo_jugador_antiguo);
    $borrado_jugador->execute();
    $numero_jugadores_borrados = $borrado_jugador->affected_rows;

    // Inserción de jugador
    $insercion_jugador = $conexion->prepare('INSERT INTO jugadores (codigo, nombre, procedencia, altura, peso, posicion, nombre_equipo) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $insercion_jugador->bindParam('issddss', $codigo_jugador_antiguo, $nombre, $procedencia, $altura, $peso, $posicion, $nombre_equipo);
    $insercion_jugador->execute();
    $numero_jugadores_insertados = $insercion_jugador->affected_rows;

    // Si el número de jugadores borrados e insertados es igual a 1, hacemos la transacción
    if (($numero_jugadores_borrados == $numero_jugadores_insertados) && ($numero_jugadores_borrados == 1)) {
        $conexion->commit();
        $correcto = true;
    } else {
        $conexion->rollback();
    }

    // En cualquier caso cerramos la conexión y devolvemos el resultado
    mysqli_close($conexion);
    return $correcto;
}